
% Matlab only has a subrou to solve constrained MINIMIZATION problems.
% We solve a maximization problem by minimizing the negative of the
% objective function.
% Title: Quadratic-Linear Programming for Mean Variance Portfolio
% Analysis
% Function Name: dcri2.m
% by Miwa Hattori
% The second formulation of the criterion function for mean-variance
% portfolio selection model.
% Defines the overall variance costs of portfolio to be minimized.

function z = dcri2(y);
z=0;
z=0;
global N
global beta
global mu;
global sigma;
for i=1:N;
    temp=0;
    for j=1:N;
        temp = temp + beta*sigma(i,j)*y(j);
    end;
    z = z + 0.5*y(i)*temp;
end;
end; % end dcri2
