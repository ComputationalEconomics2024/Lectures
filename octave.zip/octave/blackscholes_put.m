

function [price] = blackscholes_put(s, x, r, sigma, t)

d1 = (log(s / x) + (r + 0.5 * sigma * sigma) * t) / (sigma * (t ^ 0.5));
d2 = (log(s / x) + (r - 0.5 * sigma * sigma) * t) / (sigma * (t ^ 0.5));

price =  x * exp(-r * t) *normcdf(-d2) - s *normcdf(-d1);

