%Adoptbest

function a_str = adoptbest(a_str, size);

for i = 1 : size;
    for j = 1 : size;
        
         temp = zeros(3,9); % creates a 3x9 temporary matrix with zeros         
         m = 0;
        
         for u = -1 : 1;
            for v = -1 : 1;
               
                iu = i + u;
                jv = j + v;
            % periodic boundaries (torus)
            if (iu > size) iu = 1; end
            if (iu < 1)    iu = size; end
            if (jv > size) jv = 1; end
            if (jv < 1)    jv = size; end
            
            % transfers accumpayoffs and indexes to matrix
            m = m+1;
            temp(1,m) = a_str(iu,jv).accumpayoffs;
            temp(2,m) = iu;
            temp(3,m) = jv;                        
            end
         end
         
         
        % find maximum accumpayoff and corredponding indexes 
        [top topm] = max(temp(1,:));     
        bestiu = temp(2,topm);
        bestjv = temp(3,topm);
        
        a_str(i,j).actionbest = a_str(bestiu, bestjv).actionpresent;
              
    end
end

% update actions
for i = 1:size;
    for j = 1:size;
        a_str(i,j).actionprevious = a_str(i,j).actionpresent;
        a_str(i,j).actionpresent = a_str(i,j).actionbest;
    end
end
