%Value function iteration for an infinite period and no uncertainty
%model is based on the Chakravarty model as in Kendrick, Mercado and
%Amman (2006)
%Code written by Firat Yaman and modified by David Kendrick
%See the mathematics in Adda and Cooper(2003) and in
%Stokey and Lucas with Prescott (1989)
 
%clears command window and variables
clc;clear all;
 
%alpha and theta are production coefficients, beta discount factor, 
%k_grid is a grid for capital, tau is a utility
%parameter, delta is depreciation, k0 and kN define first and last point on
%the grid
 
alpha = 0.33;
beta = 0.98;
theta = 0.3;
tau = 0.5;
delta=0.1;
k0 = .1;
kN = 2.1;
 
n = 100;
step = (kN-k0) / (n-1);
k_grid = [k0:step:kN]
 
% iterlim is the iteration limit 
% tolera is the tolerance for convergence
iterlim = 5;
tolera = 0.000001 ;
 
%Output - y-grid is the grid for output
y_grid = theta*(k_grid.^alpha);
 
%vector of ones
aux = ones(n,1);
 
%current capital stocks vary along a row in kt_mesh
%future capital stocks vary along a column in kt1_mesh
%i_mesh is the corresponding mesh for investment 
%since i = k(t+1) - (1-delta) * k(t)
 
kt_mesh = aux*k_grid;
kt1_mesh = (aux*k_grid)';
i_mesh = kt1_mesh - (1-delta) * kt_mesh;
 
y_mesh = aux*y_grid;
 
%then consumption is c(t)= y(t)-i(t)
%to create the consumption mesh array
 
c_mesh = y_mesh - i_mesh;
 
%replace negative consumption with zero
cc = find(c_mesh<0);
c_mesh(cc) = 0;
clear cc;
 
%utility; to avoid negative and zero consumption we assign the lowest
%possible utility to entries with zero consumption
u_mesh = (1/(1-tau))*(c_mesh.^(1-tau));
uu = find(u_mesh == 0);
%u_mesh(uu) = -realmax
u_mesh(uu) = -10
 
%first guess for the value function; a natural starting point is one where
%investment is zero. However, any guess will
%converge to the same solution. 
clast = y_grid'
Vlast = (1/(1-tau))*(clast.^(1-tau))
Vlast(1:5)
Vlast_mesh = Vlast * (aux')
clear cc vv uu;
 
%iteration, decision rules for all capital states; from the
%utility matrix expanded by the next-period value, this picks for every
%column the highest entry (that is, for every state of capital the best
%future state of capital); tol is the convergence criterion
tol = 1
iter = 0
while ( (tol > tolera) & (iter < iterlim) )
    iter = iter + 1
    V = u_mesh + beta*(Vlast*(aux'));
    [VV,I] = max(V,[],1);
    VV_diff = (VV - Vlast')'
    tol=max(abs(VV-Vlast'))
    Vlast = VV';
end
 
% print the results of the iteration
iter
tol
Vlast
I
 
%plotting the decision rule for the capital stock, the steady state is
%where the steady state line crosses the decision rule
index=1:n;
figure(1)
plot(index,index,'-',index,I,'--');
title('Path of capital');
legend('steady state','decision rule');    
