function [price] = blackscholes_call(s, x, r, sigma, t)
 
d1 = (log(s / x) + (r + 0.5 * sigma * sigma) * t) / (sigma * (t ^ 0.5));
d2 = (log(s / x) + (r - 0.5 * sigma * sigma) * t) / (sigma * (t ^ 0.5));

price = s * normcdf(d1) - x * exp(-r * t) * normcdf(d2);

