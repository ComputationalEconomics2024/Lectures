function [error] = zero_implied(s, x, r, sigma, t, price)
error = price - blackscholes_call(s, x, r, sigma, t);
