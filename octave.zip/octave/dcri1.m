% Title: Quadratic-Linear Progr for Mean Variance Portfolio Analysis
% Function Name: dcri1.m
% by Miwa Hattori
% The first formulation of the crit function for mean-variance port
% selection model.
% Defines the expected mean return, net of variance costs, which is
% to be maximized.

function z = dcri1(x);
z=0;
global N
global beta
global mu;
global sigma;

for i=1:N;
    temp=0;
    for j=1:N;
        temp = temp + beta*sigma(i,j)*x(j);
    end;
    z = z + mu(i)*x(i) - 0.5*x(i)*temp;
end;

z=-z;
end; %end dcri1
