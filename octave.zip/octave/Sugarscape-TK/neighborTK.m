% NeighborTK
% Compute cultural influence process and trade process
%  between agent a (in cell (i,j)) and neighbor b (in cell (u,v))
% Obtain and return as aptv the geometric mean of succesive bargaining prices

function [aptv, a_str] = neighborTK(u,v,a_str,i,j,stl)

% Cultural influence process

% Check that cell (u,v) in the neighborhood of agent a is occupied by an agent
if (a_str(u,v).active == 1)

    % Define and assign values to temporary vectors
    veca = ones(1,stl);
    vecb = ones(1,stl);
    veca = a_str(i,j).tagstring;
    vecb = a_str(u,v).tagstring;

    % Randomly select a tag position in the cultural tag string
    n = ceil(rand * stl);

    % Set cultural tag in position n of agent b tag string as equal to the one of agent a
        vecb(n) = veca(n);
        a_str(u,v).tagstring = vecb;   

    % Assign to fa the fraction of agent a tags equal to R
    fa = a_str(i,j).fR;
    
    % Update the  fraction of agent b tags equal to R
    fb = sum(vecb(:) == 'R')/ stl;
    a_str(u,v).fR = fb;

    % Update the cultural group of the b agent
    if fb > (1/2) 
        a_str(u,v).group = 'R';
    else
        a_str(u,v).group = 'G';
    end
     
    %Avoid fa or fb being equal to 0 or 1
        if fa == 1  
            fa = 0.999;
        end
        
        if fb == 1
            fb = 0.999;
        end
 
        if fa == 0
            fa = 0.001;
        end
        
        if fb == 0
            fb = 0.001;
        end
        
end % End if for active agent


% Trade process

    % Set aptv (average of price trade vector) to 0 to have a value for the output 
    % function variable pgm  in case there is no trade in this function and no price is set
    aptv = 0;

    % Set first element of price trade vector ptv to 0 in case the is no trade in this
    % function and thus pv is left undefined
    ptv(1) = 0;
      
% Check that cell (u,v) in the neighborhood of agent a is occupied by an agent
if (a_str(u,v).active == 1)
   
    % Rename some variables to shorten notation
    owsua = a_str(i,j).wealthsugar;
    owspa = a_str(i,j).wealthspice;
    owsub = a_str(u,v).wealthsugar;
    owspb = a_str(u,v).wealthspice;
        
    msua = a_str(i,j).metsugar;
    mspa = a_str(i,j).metspice;
    msub = a_str(u,v).metsugar;
    mspb = a_str(u,v).metspice;
       
    mtota = msua*fa + mspa*(1-fa);
    mtotb = msub*fb + mspb*(1-fb);
    
    % Check that old wealth levels are positive 
    if (owspa > 0 && owsua > 0 && owspb > 0 && owsub > 0)
    
        signalloop = 1; % 1 means ok

        % Compute old welfare
        waold = owsua^((msua/mtota)*fa) * owspa^((mspa/mtota)*(1-fa)) ;
        wbold = owsub^((msub/mtotb)*fb) * owspb^((mspb/mtotb)*(1-fb)) ;

        % Compute old mrs 
        omrsa = (owspa / (mspa * (1-fa))) / (owsua / (msua * fa));      
        omrsb = (owspb / (mspb * (1-fb))) / (owsub / (msub * fb));
         
        % Set "direction" of mrs
            if omrsa > omrsb signalmrsold = '>';
            end
            if omrsa < omrsb signalmrsold = '<';
            end
            if omrsa == omrsb signalloop = 0; % Exit function
            end

        iptv = 0; % set ptv vector index to 0    

    % If agents old wealth levels are not positive exit loop
    else signalloop = 0; % 0 means not ok
    end
        
    % Begin trades loop
    while signalloop >= 1
    
        % Compute trade price
        p = (omrsa * omrsb)^(1/2);
            
        % Compute trade quantities as a function of price
        if p > 1  
        qsu = 1;   qsp = p;   
        end
        
        if p < 1
        qsu = 1/p; qsp = 1;
        end
        
        % Set quantities of changes in wealth according to directions of
        % trade
        if signalmrsold == '>'
            qsua = qsu; qspa = -qsp; qsub = -qsu; qspb = qsp;
        end
              
        if signalmrsold == '<'
            qsua = -qsu; qspa = qsp; qsub = qsu; qspb = -qsp;
        end
        
        % Compute new wealth levels if trade is carried out
        nwsua = owsua + qsua;
        nwspa = owspa + qspa;
        nwsub = owsub + qsub;
        nwspb = owspb + qspb;
        
        % Check that new wealth levels are positive 
        if (nwsua > 0 && nwspa > 0 && nwsub > 0 && nwspb > 0)
            
              % Compute new welfare if trade is carried out
            wanew = nwsua ^ ((msua/mtota)*fa) * nwspa ^ ((mspa/mtota)*(1-fa));
            wbnew = nwsub ^ ((msub/mtotb)*fb) * nwspb ^ ((mspb/mtotb)*(1-fb));

                % Check that trade improves welfare of both agentes
                if (wanew > waold) && (wbnew > wbold)

                    % Compute new mrs if trade is carried out
                    nmrsa = (nwspa / (mspa * (1-fa))) / (nwsua / (msua * fa)); 
                    nmrsb = (nwspb / (mspb * (1-fb))) / (nwsub / (msub * fb)); 
                    
                    % Set "direction" of mrs
                    if nmrsa > nmrsb signalmrsnew = '>';
                    end
                    if nmrsa < nmrsb signalmrsnew = '<';
                    end  
                    if nmrsa == nmrsb signalloop = 0; % Exit loop
                    end 

                    % Check that mrs do not cross over
                    if signalmrsold == signalmrsnew

                        % Carry out trade and update wealth leveles
                        owsua = nwsua;
                        owspa = nwspa;
                        owsub = nwsub;
                        owspb = nwspb;
                  
                        % Update old mrs with new mrs
                        omrsa = nmrsa;
                        omrsb = nmrsb;

                        % Store price in price vector
                        iptv = iptv + 1;
                        ptv(iptv) = p;
                        aptv = geomean(ptv);
                        
                        % Update wealth levels in agent's data structure
                        a_str(i,j).wealthspice = nwsua;
                        a_str(u,v).wealthspice = nwspa;
                        a_str(i,j).wealthsugar = nwsub;
                        a_str(u,v).wealthsugar = nwspb;
                           
                    % Agents mrs cross over thus exit loop
                    else signalloop = 0;
                    end 
                
                % Agents welfare does not improve thus exit loop    
                else signalloop = 0;
                end

        % Agents wealth is not positive thus exit loop
        else signalloop = 0;
        end
        
    end % End trades loop
              
end  % End if for active agent    


