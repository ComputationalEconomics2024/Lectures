%InitagentsTK
%Initialize agents population 

function a_str = initagentsTK(size, vision, metsugar, metspice, initwup, initwlow, stl)

for i = 1:size;
    for j = 1:size;
        
        if (rand < 0.3)
            a_str(i,j).active = 1; % put an agent on this location
            a_str(i,j).metsugar = ceil(rand * metsugar);
            a_str(i,j).metspice = ceil(rand * metspice);
            a_str(i,j).vision = ceil(rand * vision);
            a_str(i,j).wealthsugar = rand * (initwup-initwlow) + initwlow; 
            a_str(i,j).wealthspice = rand * (initwup-initwlow) + initwlow; 

            % Create a vector with cultural tag string
            ve = ones(1,stl);
            for n = 1:stl
                if rand > 0.5 
                    ve(n) = 'R';
                else ve(n) = 'G';
                end
            end
            a_str(i,j).tagstring = ve;
             
            %Initialize the cultural group to which de agent belongs to
            fR = sum(ve(:) == 'R')/stl;
            if fR > (1/2)
                a_str(i,j).group = 'R';
            else
                a_str(i,j).group = 'G';
            end
            a_str(i,j).fR = fR;
            
            
        else
            a_str(i,j).active = 0; %keep this location empty
            a_str(i,j).metsugar = 0;
            a_str(i,j).metspice = 0;
            a_str(i,j).vision = 0;
            a_str(i,j).wealthsugar = 0; 
            a_str(i,j).wealthspice = 0; 
            a_str(i,j).tagstring = 0;
            a_str(i,j).group = 0;
            a_str(i,j).fR = 0;
                
        end        
    end
end

