% SeeTK
% Explore neighborhood looking for agents to trade with

function [avpav, a_str] = seeTK(i,j,k,a_str,size,stl)

% Define pav price vector of agent's trades and initialize vector index
% and average price of agent's trades
pav(1)= 0;
ipav = 0;
avpav = 0;

south = [i+k  size  i+k-size  j  i+k  j];
north = [k-i  -1  i-k+size  j  i-k  j];
east  = [j+k  size  i  j+k-size  i  j+k];
west  = [k-j  -1  i  j-k+size  i  j-k];

c{1} = south;  c{2} = north;  c{3} = east;  c{4} = west;

for m = randperm(4)
	if (c{m}(1) > c{m}(2))
        u = c{m}(3);
        v = c{m}(4);
        [aptv, a_str] = neighborTK(u,v,a_str,i,j,stl);
	else
        u = c{m}(5);
        v = c{m}(6);
        [aptv, a_str] = neighborTK(u,v,a_str,i,j,stl);
    end

    % Store price of one trade between agent and one neighbor
    if aptv > 0
        ipav = ipav + 1;
        pav(ipav) = aptv;
        avpav = geomean(pav);
    end
end

