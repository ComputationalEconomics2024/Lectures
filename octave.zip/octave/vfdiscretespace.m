%Value function iteration for an infinite period and uncertainty
%model is based on the Chakravarty model as in Kendrick, Mercado and
%Amman (2006)
%Code written by Firat Yaman and modified by David Kendrick
%See the mathematics in Adda and Cooper(2003) and in
%Stokey and Lucas with Prescott (1989)
 
%clears command window and variables
clc;clear all;
 
%alpha and theta are production coefficients, beta discount factor, 
%k_grid is a grid for capital, tau is a utility
%parameter, delta is depreciation, k0 and kN define first and last
%point on the grid
 
alpha = 0.33;
beta = 0.98;
theta = 0.3;
tau = 0.5;
delta=0.1;
k0 = .1;
kN = 2.1;
n = 20;
step = (kN-k0) / (n-1);
k_grid = [k0:step:kN];
 
iterlim = 5;
tolera = 0.000001;
 
z_low = 0.90;
z_high = 1.10;  
 
%probability of going from low to low, low to high
P(1,1)=0.5;P(1,2)=1-P(1,1); 
%probability of going from high to low, high to high
P(2,1)=0.1;P(2,2)=1-P(2,1); 
 
%Output - y-grid is the grid for output
y_grid_l = z_low*theta*(k_grid.^alpha);
y_grid_h = z_high*theta*(k_grid.^alpha);
 
%vector of ones
aux = ones(n,1);
 
%current capital stocks vary along a row in kt_mesh
%future capital stocks vary along a column in kt1_mesh
%i_mesh is the corresponding mesh for investment 
%since i = k(t+1) - (1-delta) * k(t)
 
kt_mesh = aux*k_grid;
kt1_mesh = (aux*k_grid)';
i_mesh = kt1_mesh - (1-delta) * kt_mesh;
 
y_mesh_l = aux*y_grid_l;
y_mesh_h = aux*y_grid_h;
 
%then consumption is c(t)= y(t)-i(t)
%to create the consumption mesh array
c_mesh_l = y_mesh_l - i_mesh;
c_mesh_h = y_mesh_h - i_mesh;
 
%replace negative consumption with zero
cc = find(c_mesh_l<0);
c_mesh_l(cc) = 0;
clear cc;
cc = find(c_mesh_h<0);
c_mesh_h(cc) = 0;
clear cc;
 
%utility; to avoid negative and zero consumption we asign the lowest
%possible utility to entries with zero consumption
u_mesh_l = (1/(1-tau))*(c_mesh_l.^(1-tau));
uu = find(u_mesh_l == 0);
%u_mesh(uu) = -realmax
u_mesh_l(uu) = -10;
u_mesh_h = (1/(1-tau))*(c_mesh_h.^(1-tau));
uu = find(u_mesh_h == 0);
%u_mesh(uu) = -realmax
u_mesh_h(uu) = -10;
 
%first guess for the value function; a natural starting point is one
%where there is no investment and consumption therefore equals
%output.
clast_l = y_grid_l';
Vlast_l = (1/(1-tau))*(clast_l.^(1-tau));
clear cc vv uu;
clast_h = y_grid_h';
Vlast_h = (1/(1-tau))*(clast_h.^(1-tau));
clear cc vv uu;
 
%iteration, decision rules for all capital states; from the
%utility matrix expanded by the next-period value, this picks for every
%column the highest entry (that is, for every state of capital the best
%future state of capital); tol is the convergence criterion
tol = 1
iter = 0
while ( (tol > tolera) & (iter < iterlim) )
    iter = iter + 1;
    V_l=u_mesh_l + beta*(P(1,1)*Vlast_l*(aux')+P(1,2)*Vlast_h*(aux'));
    V_h=u_mesh_h + beta*(P(2,1)*Vlast_l*(aux')+P(2,2)*Vlast_h*(aux'));
    [VV_l,I_l] = max(V_l,[],1);
    [VV_h,I_h] = max(V_h,[],1);
    tol_l=max(abs(VV_l-Vlast_l'));
    tol_h=max(abs(VV_h-Vlast_h'));
    tol=max(tol_l,tol_h);
    Vlast_l = VV_l';
    Vlast_h = VV_h';
end
 
iter
tol
Vlast_l
Vlast_h
I_l
I_h
 
 
%plotting the decision rule for the capital stock, the steady state is
%where the steady state line crosses the decision rule
index=1:n;
figure(1)
plot(index,index,'-',index,I_l,'--',index,I_h,':');
title('Path of capital');
legend('steady state','decision rule low','decision rule high');    