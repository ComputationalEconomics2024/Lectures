%Spatialgame

% Initialization of variables
clc;
clear all;
size = 49;  
nruns = 25;
b = 1.85;
 
% Assign all cooperators to the grid
 for i = 1:size;
     for j = 1:size;
     a_str(i,j).actionpresent = 1;
     a_str(i,j).actionprevious = 1;
     a_str(i,j).color = 4;
     end
 end
         
% Place one defector on the center of the grid
i = ceil(size/2);
j = ceil(size/2);
a_str(i,j).actionpresent = 0;
a_str(i,j).actionprevious = 0;
a_str(i,j).color = 1;
               
% Begin main loop
for runs = 1:nruns;

% Display results 
displayresults(a_str, size, nruns, runs);         

% Play games: each player plays against its neighbors and itself       
a_str = playgames(a_str, size, b); 

% Adopt best action: each  adopts the action with highest accumulated 
% payoff amongst its neighbors and itself     
a_str = adoptbest(a_str, size); 

% Adopt color: each agent compares its previous action against 
% its present action and adopts the corresponding color
a_str = adoptcolor(a_str, size); 
 
end
