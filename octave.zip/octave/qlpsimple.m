% Title: Simple Quadratic-Linear Problem
% Program name: qlpsimple.m
% Based on qlpabel.m program by Amman, Hattori, Kendrick and Salas

%   Preliminaries
t = 3;   a = 0.7;   b = -0.3;   x0 = -1;
u = zeros(1,t);   x = zeros(1,t);
sum = 0;   k = 0;

%   The Forward loop
xold = x0;
while k <= t;    
  glarge = - a / b;
  uopt = glarge * xold;
  xnew = a * xold + b * uopt;
  sum = sum + 0.5 * xold^2;
  x(1,k+1) = xold;
  u(1,k+1) = uopt;
  xold = xnew;
  k = k+1;
end;                        

%   Print the solution
u = u'                        
x = x'                        
Criterion = sum        
 
