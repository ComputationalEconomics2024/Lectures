%Displayresults

function displayresults(a_str, size, nruns, runs);

for i = 1:size;
    for j = 1:size;
        a(i,j) = a_str(i,j).color;
    end
end

figure(1);
subplot(ceil(sqrt(nruns)), ceil(sqrt(nruns)),runs), 
map = [1 0 1
       0 1 0
       1 1 0
       0 0 1];
colormap(map);
imagesc(a);
axis square; 
 
