% MoveagentT
% Move agent to best location and updates wealth

function a_str = moveagentT(a_str, i, j, tempssugar, ...
    tempsspice, tempi, tempj, move) 

if move == 'yes'
    
    a_str(tempi,tempj) = a_str(i,j);
    
    % Set old location to unoccupied
    a_str(i,j).active = 0; 
    a_str(i,j).vision = 0; 
    a_str(i,j).metsugar = 0; 
    a_str(i,j).metspice = 0;
    a_str(i,j).wealthsugar = 0;
    a_str(i,j).wealthspice = 0;
    
    % Update wealth at new location
    a_str(tempi,tempj).wealthsugar = ...
        a_str(tempi,tempj).wealthsugar + tempssugar - a_str(tempi,tempj).metsugar;
    a_str(tempi,tempj).wealthspice = ...
        a_str(tempi,tempj).wealthspice + tempsspice - a_str(tempi,tempj).metspice;
    
    % If wealth is less than zero set location to unoccupied
    if (a_str(tempi,tempj).wealthsugar <= 0) || (a_str(tempi,tempj).wealthspice <= 0)
        a_str(tempi,tempj).active = 0; 
        a_str(tempi,tempj).vision = 0; 
        a_str(tempi,tempj).metsugar = 0; 
        a_str(tempi,tempj).metspice = 0;
        a_str(tempi,tempj).wealthsugar = 0;
        a_str(tempi,tempj).wealthspice = 0;
    end
else
    
    % Agent stays in position and updates wealth
    a_str(i,j).wealthsugar = a_str(i,j).wealthsugar + tempssugar - a_str(i,j).metsugar;
    a_str(i,j).wealthspice = a_str(i,j).wealthspice + tempsspice - a_str(i,j).metspice;
    
    % If wealth is less than zero set location to unoccupied
    if (a_str(i,j).wealthsugar <= 0) || (a_str(i,j).wealthspice <= 0)
        a_str(i,j).active = 0; 
        a_str(i,j).vision = 0; 
        a_str(tempi,tempj).metsugar = 0; 
        a_str(tempi,tempj).metspice = 0;
        a_str(tempi,tempj).wealthsugar = 0;
        a_str(tempi,tempj).wealthspice = 0;
    end
end