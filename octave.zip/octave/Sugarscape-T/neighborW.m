% NeighborW
% Check if available sugar and spice in location are welfare improving  

function [tempssugar, tempsspice, tempi, tempj, move] = ...
    neighborW(u,v,a_str,ssugar,sspice,tempssugar,tempsspice,tempi,tempj,i,j)

% Initialize welfare variables at zero and move variable to not, just to have them defined 
welfareij = 0;
welfareuv = 0;
move = 'not';

% Compute and compare welfare at current location and potential new free location
if (a_str(u,v).active == 0)

    % Rename some variables to shorten notation
    wsu = a_str(i,j).wealthsugar;
    wsp = a_str(i,j).wealthspice;       
    msu = a_str(i,j).metsugar;
    msp = a_str(i,j).metspice;       
    mtot = msp + msu;      
    
    % Compute welfare
    welfareij = (wsu + ssugar(i,j))^(msu/mtot) * (wsp + sspice(i,j))^(msp/mtot) ;
    welfareuv = (wsu + ssugar(u,v))^(msu/mtot) * (wsp + sspice(u,v))^(msp/mtot) ;
       
    if (welfareuv >= welfareij)
        move = 'yes';
        tempssugar = ssugar(u,v);
        tempsspice = sspice(u,v);  
        tempi = u;
        tempj = v;
    else 
        move = 'not';
    end
end