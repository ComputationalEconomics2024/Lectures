% NeighborT
% Compute barganing process between agent a (in cell (i,j)) and neighbor b (in cell (u,v))
% Obtain and return as aptv the geometric mean of succesive bargaining prices

function [aptv, a_str] = neighborT(u,v,a_str,i,j)

% Set aptv (average of price trade vector) to 0 to have a value for the output function variable pgm  
% in case there is no trade in this function and no price is set
aptv = 0;

% Set first element of price trade vector ptv to 0 in case the is no trade in this
% function and thus ptv is left undefined
ptv(1) = 0;

% Check that cell (u,v) in the neighborhood of agent a is occupied by an agent
if (a_str(u,v).active == 1)   
    
    % Rename some variables to shorten notation
    owsua = a_str(i,j).wealthsugar;
    owspa = a_str(i,j).wealthspice;
    owsub = a_str(u,v).wealthsugar;
    owspb = a_str(u,v).wealthspice;
        
    msua = a_str(i,j).metsugar;
    mspa = a_str(i,j).metspice;
    msub = a_str(u,v).metsugar;
    mspb = a_str(u,v).metspice;
       
    mtota = mspa + msua;
    mtotb = mspb + msub;    
    
    % Check that old wealth levels are positive 
    if (owspa > 0 && owsua > 0 && owspb > 0 && owsub > 0)
    
        signalloop = 'yes'; % Assign initianl value to signalloop

        % Compute old welfare
        waold = owsua^(msua/mtota) * owspa^(mspa/mtota) ;
        wbold = owsub^(msub/mtotb) * owspb^(mspb/mtotb) ;

        % Compute old mrs 
        omrsa = (owspa / mspa) / (owsua / msua);      
        omrsb = (owspb / mspb) / (owsub / msub);
         
        % Set "direction" of mrs
            if omrsa > omrsb 
                signalmrsold = '>';
            end
            if omrsa < omrsb 
                signalmrsold = '<';
            end
            if omrsa == omrsb 
                signalloop = 'not'; % Exit function
            end

        iptv = 0; % set ptv vector index to 0    

    % If agents old wealth levels are not positive exit loop
    else signalloop = 'not'; % Exit function
    end
    
    signaltrade = 'not'; % Assign initial value to signaltrade
    
    % Begin trades loop
    while signalloop == 'yes'
    
        % Compute trade price
        p = (omrsa * omrsb)^(1/2);
            
        % Compute trade quantities as a function of price
        if p > 1  
        qsu = 1;   qsp = p;   
        end
        
        if p < 1
        qsu = 1/p; qsp = 1;
        end
        
        % Set quantities of changes in wealth according to directions of
        % trade
        if signalmrsold == '>'
            qsua = qsu; qspa = -qsp; qsub = -qsu; qspb = qsp;
        end
              
        if signalmrsold == '<'
            qsua = -qsu; qspa = qsp; qsub = qsu; qspb = -qsp;
        end
        
        % Compute new wealth levels if trade is carried out
        nwsua = owsua + qsua;
        nwspa = owspa + qspa;
        nwsub = owsub + qsub;
        nwspb = owspb + qspb;
        
        % Check that new wealth levels are positive 
        if (nwsua > 0 && nwspa > 0 && nwsub > 0 && nwspb > 0)
            
                % Compute new welfare if trade is carried out
                wanew = nwsua ^ (msua/mtota) * nwspa ^ (mspa/mtota);
                wbnew = nwsub ^ (msub/mtotb) * nwspb ^ (mspb/mtotb);

                % Check that trade improves welfare of both agentes
                if (wanew > waold) && (wbnew > wbold)

                    % Compute new mrs if trade is carried out
                    nmrsa = (nwspa / mspa) / (nwsua / msua); 
                    nmrsb = (nwspb / mspb) / (nwsub / msub); 
                    
                    % Set "direction" of mrs
                    if nmrsa > nmrsb signalmrsnew = '>';
                    end
                    if nmrsa < nmrsb signalmrsnew = '<';
                    end  
                    if nmrsa == nmrsb signalloop = 'not'; % Exit loop
                    end 

                    % Check that mrs do not cross over
                    if signalmrsold == signalmrsnew
                        
                        signaltrade = 'yes';

                        % Carry out trade and update wealth leveles
                        owsua = nwsua;
                        owspa = nwspa;
                        owsub = nwsub;
                        owspb = nwspb;
                  
                        % Update old mrs with new mrs
                        omrsa = nmrsa;
                        omrsb = nmrsb;

                        % Store price in price vector
                        iptv = iptv + 1;
                        ptv(iptv) = p;
                        aptv = geomean(ptv);
                                                                          
                    % Agents mrs cross over thus exit loop
                    else signalloop = 'not';
                    end 
                
                % Agents welfare does not improve thus exit loop    
                else signalloop = 'not';
                end

        % Agents wealth is not positive thus exit loop
        else signalloop = 'not';
        end
        
    end % End trades loop
    
    if signaltrade == 'yes'
        % Update wealth levels of agents a and b in data structure if there was at
        % least one trade between them
        a_str(i,j).wealthspice = nwsua;
        a_str(u,v).wealthspice = nwspa;
        a_str(i,j).wealthsugar = nwsub;
        a_str(u,v).wealthsugar = nwspb; 
       
    end
                      
end  % End if for active agent    


