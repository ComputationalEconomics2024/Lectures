% DispagentlocT
% Transform field "agent" from data structure into matrix and display agents locations    

function dispagentlocT(a_str, size, nruns, runs)
a = zeros(size); av = zeros(size); amsugar = zeros(size); amspice = zeros(size);

for i = 1:size;
    for j = 1:size;
        if (a_str(i,j).active == 1)
	        a(i,j) = a_str(i,j).active;
            av(i,j) = a_str(i,j).vision;
            amsugar(i,j) = a_str(i,j).metsugar;
            amspice(i,j) = a_str(i,j).metspice;
            awsu(i,j) = a_str(i,j).wealthsugar;
            awsp(i,j) = a_str(i,j).wealthspice;
        end
    end
end


if (runs==1 || runs==5 || runs==10 || runs==50 ||runs==100 || runs==nruns)
    figure(runs)
    spy(a)
    title(['run:  ', num2str(runs)])
    axis square;
end

avgvision = sum(sum(av))/sum(sum(a));
avgmsugar = sum(sum(amsugar))/sum(sum(a));
avgmspice = sum(sum(amspice))/sum(sum(a));