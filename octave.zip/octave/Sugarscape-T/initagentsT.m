%InitagentsT
%Initialize agents population 

function a_str = initagentsT(size, vision, metsugar, metspice, initwup, initwlow)

for i = 1:size;
    for j = 1:size;
        
        if (rand < 0.3)
            a_str(i,j).active = 1; % put an agent on this location
            a_str(i,j).metsugar = ceil(rand * metsugar);
            a_str(i,j).metspice = ceil(rand * metspice);
            a_str(i,j).vision = ceil(rand * vision);
            a_str(i,j).wealthsugar = rand * (initwup-initwlow) + initwlow; 
            a_str(i,j).wealthspice = rand * (initwup-initwlow) + initwlow; 

        else
            a_str(i,j).active = 0; % keep this location empty
            a_str(i,j).metsugar = 0;
            a_str(i,j).metspice = 0;
            a_str(i,j).vision = 0;
            a_str(i,j).wealthsugar = 0; 
            a_str(i,j).wealthspice = 0; 
            
        end
    end
end

