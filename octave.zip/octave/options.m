pkg load statistics

% matlab code to compute the black scholes pricing formula
% input parameters



s=50;
x=50;
r=0.1;
t=0.4167;
sigma=0.40;

blackscholes_call(s, x, r, sigma, t)
blackscholes_put(s, x, r, sigma, t)

nstep=50;
binomial_call(s, x, r, sigma, t, nstep)
binomial_put(s, x, r, sigma, t, nstep)


sx     = zeros(100,1);
xtemp1  = zeros(100,1);
xtemp2  = zeros(100,1);
sx     = [1:1:100];

for i=1:100
    xtemp1(i) =blackscholes_call(sx(i), x, r, sigma, t);
    xtemp2(i) =blackscholes_put(sx(i), x, r, sigma, t);
end


plot(xtemp1);
plot(xtemp2);



mcruns=1000;
americanoption(s, x, r, sigma, t, mcruns)


mcoption(s, x, r, sigma, t, mcruns)




price=5;
sigma0=0.1;
implied_blackscholes_call(s, x, r, sigma0, t, price)


x=[-3:0.1:3];
p=normcdf(x);
plot(x,p)
title('Normalized form of the normal cdf')
xlabel('d')
ylabel('N(d)');

