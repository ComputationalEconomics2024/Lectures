% Celautom

clear all;
% establish dimensions of the grid
nrows=11;
ncolumns=11;

% set the elements of the grid equal to zero
grid(nrows,ncolumns)=0;

% set the initial position of the nonzero element
initposition = ceil(ncolumns/2);
grid(1,initposition) = 1;

% establish Wolfram rule to be simulated
rulenumber=254;

% transform the decimal representation of the rule into binary
rulebin=dec2bin(rulenumber,8);

% create a vector containing the binary representation of the rule
for i=1:8
    r(i)=str2num(rulebin(i));
end

% apply the rule to each element of the grid
for i=1:nrows-1;
    for j=1:ncolumns; 
 
        % implement periodic boundary conditions
        if ((j-1) < 1) topleft = grid(i,ncolumns);
            else topleft = grid(i,j-1); end

        top = grid(i,j); 

        if ((j+1) > ncolumns) topright = grid(i,1);
            else topright = grid(i,j+1); end
    
        % apply the rule
        if (topleft==1 & top==1 & topright ==1) grid(i+1,j) = r(1); end
        if (topleft==1 & top==1 & topright ==0) grid(i+1,j) = r(2); end
        if (topleft==1 & top==0 & topright ==1) grid(i+1,j) = r(3); end
        if (topleft==1 & top==0 & topright ==0) grid(i+1,j) = r(4); end
        if (topleft==0 & top==1 & topright ==1) grid(i+1,j) = r(5); end
        if (topleft==0 & top==1 & topright ==0) grid(i+1,j) = r(6); end
        if (topleft==0 & top==0 & topright ==1) grid(i+1,j) = r(7); end
        if (topleft==0 & top==0 & topright ==0) grid(i+1,j) = r(8); end
    end
end


% choose two colors from the bone colormap to represent each cell state
% in our case they will be white and black
colormap(bone(2));
% since imagesc will display cells with low values as black and cells with
% high values as white, we make the ones in the grid equal to minus one
imagesc(grid * (-1));
title(rulenumber);
axis square;