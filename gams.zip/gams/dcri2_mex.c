/*
 * MATLAB Compiler: 2.1
 * Date: Sun Oct 12 22:32:12 2008
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-x" "-W" "mex" "-L" "C"
 * "-t" "-T" "link:mexlibrary" "libmatlbmx.mlib" "dcri2.m" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#include "libmatlb.h"
#include "dcri2.h"

mxArray * mu = NULL;

mxArray * sigma = NULL;

static mexGlobalTableEntry global_table[2]
  = { { "mu", &mu }, { "sigma", &sigma } };

static mexFunctionTableEntry function_table[1]
  = { { "dcri2", mlxDcri2, 2, 1, &_local_function_table_dcri2 } };

static _mexInitTermTableEntry init_term_table[1]
  = { { InitializeModule_dcri2, TerminateModule_dcri2 } };

static _mex_information _mex_info
  = { 1, 1, function_table, 2, global_table, 0, NULL, 1, init_term_table };

/*
 * The function "mexLibrary" is a Compiler-generated mex wrapper, suitable for
 * building a MEX-function. It initializes any persistent variables as well as
 * a function table for use by the feval function. It then calls the function
 * "mlxDcri2". Finally, it clears the feval table and exits.
 */
mex_information mexLibrary(void) {
    return &_mex_info;
}
