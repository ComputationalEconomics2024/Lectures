%MATLAB Code for a Markowitz Optimal Portfolio Problem}
% Title: Quadratic-Linear Programming for Mean Variance Portfolio
% Analysis
% Program name: portfolio.m
% by Miwa Hattori
% Implementation of the mean-variance portfolio selection models
% with two alternative formulations in Matlab:
% maximizing expected mean return, net of variance costs and
% minimizing the overall variance costs of portfolio.

clear all;

%
% Preliminaries
%

theta=10; % Minimum mean-return on portfolio under formulation 2.
beta=2; % Subjective weight on returns variance of equities.
N=3; % Number of available equity types.
mu=[8; 12; 15]; 

% Column vector of mean annual returns on equities 1
% through N (%).
% Table of covariances between returns on equities.
sigma=[6 -5 4;-5 17 -11;4 -11 24];

%
% Provide initial "guesses" for portfolio vectors.
%

x0=ones(N,1)/N; 

% Column vector of fractions of portfolio invested in
% equity i, initialized to 1/N.

y0=ones(N,1)/N; % Column vector of fractions of portfolio invested in

% equity i, initialized to 1/N.
%
% Constraints for optimization
% Matlab only has a function that solves a constrained nonlinear
% MINIMIZATION problem. See Help file for function "fmincon".
% fmincon finds a minimum of a multivariable function f(x)subject to
% A*x$<$= b, Aeq*x= beq, lb$<$= x $<$=ub where x, b, beq, lb, and
% ub are vectors, A and Aeq are murices.
%

A1=[]; % Set of linear inequality constraints under formulation 1.

b1=[]; 

A2=-mu'; % Set of linear inequality constraints under formulation 2:

b2=-theta; % Desired minimum mean-return on portfolio y $>$= theta (%).

Aeq=[1 1 1]; % Set of linear equality constraints.

beq=1; % Fractions x(i) must add to 1, fractions y(i) must add to 1.

lb=[0;0;0]; % Non negativity constraints on x(i) and y(i)

ub=[];

nonlcon=[]; % Non linear constraints-- none in this problem.

options=optimset('MaxIter',60);

%
% Definition of the criterion functions
% Functions dcri1, dcri2 are called. See files dcri1.m, dcri2.m.
%

[x,fval,exitflag,output]=fmincon(@dcri1,x0,A1,b1,Aeq,beq,lb,ub,nonlcon,options,beta,N,mu,sigma);

x

fval

[y,fval,exitflag,output]=fmincon(@dcri2,y0,A2,b2,Aeq,beq,lb,ub,nonlcon,options,beta,N,mu,sigma);

y

fval

% Title: Quadratic-Linear Progr for Mean Variance Portfolio Analysis
% Function Name: dcri1.m
% by Miwa Hattori 
% The first formulation of the crit function for mean-variance port
% selection model.
% Defines the expected mean return, net of variance costs, which is 
% to be maximized.

function z = dcri1(x,beta,N,mu,sigma); 
z=0;
for i=1:N;
    temp=0;
    for j=1:N;
        temp = temp + beta*sigma(i,j)*x(j);
    end;
    z = z + mu(i)*x(i) - 0.5*x(i)*temp;
end;

z=-z;
end; %end dcri1

% Matlab only has a subrou to solve constrained MINIMIZATION problems.
% We solve a maximization problem by minimizing the negative of the
% objective function.
% Title: Quadratic-Linear Programming for Mean Variance Portfolio
% Analysis
% Function Name: dcri2.m
% by Miwa Hattori 
% The second formulation of the criterion function for mean-variance
% portfolio selection model.
% Defines the overall variance costs of portfolio to be minimized.

function z = dcri2(y,beta,N,mu,sigma); 
z=0;
for i=1:N;
    temp=0;
    for j=1:N;
        temp = temp + beta*sigma(i,j)*y(j);
    end;
    z = z + 0.5*y(i)*temp;
end;
end; % end dcri2