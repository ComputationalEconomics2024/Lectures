%Adoptcolor

function a_str = adoptcolor(a_str, size);

for i = 1:size;
        for j = 1:size;
 
        if (a_str(i,j).actionprevious == 0) && (a_str(i,j).actionpresent == 0)
         a_str(i,j).color = 1; %magenta red
        end
 
        if (a_str(i,j).actionprevious == 0) && (a_str(i,j).actionpresent == 1)
         a_str(i,j).color = 2; %green
        end
 
        if (a_str(i,j).actionprevious == 1) && (a_str(i,j).actionpresent == 0)
         a_str(i,j).color = 3; %yellow
        end
 
        if (a_str(i,j).actionprevious == 1) && (a_str(i,j).actionpresent == 1)
         a_str(i,j).color = 4; %blue
        end
 
        end
end
