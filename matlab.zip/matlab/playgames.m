%Playgames

function a_str = playgames(a_str, size, b);

% sets accumulated payoffs to zero
for i = 1 : size;
    for j = 1 : size;
        a_str(i,j).accumpayoffs = 0;
    end
end
 
% the game 
for i = 1 : size;
    for j = 1 : size;
        
        % u and v indexes to move around neighborhood of player (i,j)
        for u = -1 : 1;
            for v = -1 : 1;
                iu = i + u;
                jv = j + v;
                
            % periodic boundaries (torus) 
            if (iu > size) iu = 1; end
            if (iu < 1)    iu = size; end
            if (jv > size) jv = 1; end
            if (jv < 1)    jv = size; end
            
            % definition of actions for player 1 and player 2
            actionp1 = a_str(i,j).actionpresent;
            actionp2 = a_str(iu,jv).actionpresent;
            
            % the game is played
            if ((actionp1 == 0) && (actionp2 == 0))
                a_str(i,j).accumpayoffs = a_str(i,j).accumpayoffs + 0;
            end
 
            if ((actionp1 == 1) && (actionp2 == 0))
                a_str(i,j).accumpayoffs = a_str(i,j).accumpayoffs + 0;
            end
 
            if ((actionp1 == 0) && (actionp2 == 1))
                a_str(i,j).accumpayoffs = a_str(i,j).accumpayoffs + b;
            end
            if ((actionp1 == 1) && (actionp2 == 1))
                a_str(i,j).accumpayoffs = a_str(i,j).accumpayoffs + 1;
            end
        
            end
        end
    end
end
