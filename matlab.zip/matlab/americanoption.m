function [price]=american(s0, x, r, sigma, t, mcruns)

% by increasing nstep you increase the accuracy
% iflag = 0 call option, iflag = 1 put option

    nsteps =10;
    dt = t / nsteps;
    drift = (r - 0.5 * sigma ^ 2) * dt;
    rm = norminv(rand(nsteps,mcruns));
    
    price=0;
    sum1=0.0;  
    for j=1:mcruns
        
        t1=0;
        smax=-1.0;
        st = s0;
        csum=0.0;
        t0=0;
        s1=0;
        
        for i=1:nsteps;
            
            ds = rm(i,j)* sqrt(dt);
            st = st * exp(drift + sigma * ds);
            csum = max(0,st-x*exp(-r*i*dt));
            
            if csum > smax
                smax = csum;
            end
        end
       
        sum1=sum1 + smax;
       
    end
        
    price = sum1/mcruns;