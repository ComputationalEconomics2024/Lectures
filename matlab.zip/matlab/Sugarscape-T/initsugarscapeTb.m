% InitsugarscapeTb
% Generate a Sugarscape with one peak in given coordinates

function stemp = initsugarscapeTb(size, maxresource, x, y)

for i = 1:size;
    for j = 1:size;
        if (x(i) == 0 && y(j) == 0)
            stemp(i,j) = maxresource; 
        else
            stemp(i,j) = maxresource / (abs(x(i)) + abs(y(j)));
       end
    end
end
