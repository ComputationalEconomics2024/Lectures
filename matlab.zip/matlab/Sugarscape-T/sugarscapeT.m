%SugarscapeT

%Sugarscape: four-peak sugarscape, two goods, rule: Ginf
%Agents:  moving sequence: random, view: four directions, 
%Rules: M (Movement) and T (Trade)

clear all; clc;

%Initialize model parameters
nruns = 50; 
size = 50; %even number
metsugar = 5;
metspice = 5;
vision = 5; %set always smaller than size
maxsugar = 30;
maxspice = 30; 
initwup = 50;
initwlow = 25;

%Initialize sugarscape and display 
[s, ssugar, sspice] = initsugarscapeT(size, maxsugar, maxspice);

%Initialize agents population 
a_str = initagentsT(size, vision, metsugar, metspice, initwup, initwlow);

%Main loop (runs)  
for runs = 1:nruns;
   
    iprv = 0; %Set initial index value for price vector prv
   
    %Display agents locations 
	dispagentlocT(a_str, size, nruns, runs);
    
	%Select agents in a random order
    for i = randperm(size);
        for j= randperm(size);
             
            if (a_str(i,j).active == 1) %is there an angent on this location?
                             
                %Agent explores sugarscape in random directions and selects best location
                tempssugar = ssugar(i,j);
                tempsspice = sspice(i,j);
                tempi = i;  
                tempj = j;
               
                for k = a_str(i,j).vision : -1 : 1;  
                    [tempssugar, tempsspice, tempi, tempj, move] = ...
                    seeW(i,j,k,a_str,ssugar,sspice,size,tempssugar,tempsspice,tempi,tempj);                 
                end
                
                %Agent moves to best location, updates sugar stock and eats sugar
                a_str = moveagentT(a_str, i, j, ...
                    tempssugar, tempsspice, tempi, tempj, move); 
                
                %Agent explores sugarscape in random directions and trades with neighbors
                prv(1) = 1;
                for k = a_str(i,j).vision : -1 : 1;  
                       [avpav, a_str] = seeT(i,j,k,a_str,size);   
                        
                       %Store average price of agent trades with its neighbors                     
                       if avpav > 0
                           iprv = iprv + 1;
                           prv(iprv) = avpav;                           
                       end
                end
                
            end  % for if active agent
            
        end  % for j loop
    end  % for i loop
   
   %Compute average price for one run and store in vector to plot later
   avprv = geomean(prv); 
   avprruns(runs) = avprv; 
   axesx(runs) = runs;
   
   
end  % for runs

%Plot average prices
figure(3); 
scatter(axesx,avprruns);
axis square;

