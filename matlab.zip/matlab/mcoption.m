function [price]=mcoption(s0, x, r, sigma, t, mcruns)

% by increasing nstep you increase the accuracy
% iflag = 0 call option, iflag = 1 put option

    nsteps = 10;
    dt = t / nsteps;
    drift = (r - 0.5 * sigma ^ 2) * dt;
    
    sum1 = 0.0;   
    for j=1:mcruns
        
        st = s0;
        for i=1:nsteps
            ds = norminv(rand(1))* sqrt(dt);
            st = st * exp(drift + sigma * ds);
        end
        
        if (st - x) > 0.0 ;
            sum1 = sum1 + st - x;
        end
    end
        
    price =sum1 * exp(-r * t) / mcruns;