% Matlab code to compute the binomial tree for American options

% input parameters
s=50
x=50
r=0.1
t=0.4167
sigma=0.4
nstep = 5
f=zeros(nstep+1,nstep+1);

dt = t / nstep;
u = exp(sigma * (dt ^ 0.5));
d = 1/u;
a = exp(r * dt);
p = (a - d) / (u - d);
uloop=0;
u2=0;

u2=u*u;
uloop=u^(-nstep);
for j=0:nstep
    sum = s*uloop - x;
    f(nstep+1,j+1)=max(sum,0);
    uloop=uloop*u2;
end

for i=nstep-1:-1:0
      uloop=u^(-i);
      u2=u*u;
      for j=0:i
          sum = s*uloop - x;
          sum1= exp(-r*dt)*(p*f(i+2,j+2)+(1.0-p)*f(i+2,j+1));
          f(i+1,j+1)=max(sum,sum1);
          uloop=uloop*u2;
      end    
end

call_option = f(1,1)


f = zeros(nstep+1,nstep+1);


u2=u*u;
uloop=u^(-nstep);
for j=0:nstep
    sum = -s*uloop + x;
    f(nstep+1,j+1)=max(sum,0);
    uloop=uloop*u2;
end

for i=nstep-1:-1:0
      uloop=u^(-i);
      u2=u*u;
      for j=0:i
          sum = -s*uloop + x;
          sum1= exp(-r*dt)*(p*f(i+2,j+2)+(1.0-p)*f(i+2,j+1));
          f(i+1,j+1)=max(sum,sum1);
          uloop=uloop*u2;
      end    
end

put_option = f(1,1)
