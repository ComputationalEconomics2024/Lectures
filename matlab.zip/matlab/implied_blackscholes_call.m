function [sigma1]=implied_blackscholes_call(s, x, r, sigma0, t, price)

    eps = 1E+16;
    
    while eps > 0.01
        mylc = (blackscholes_call(s, x, r, sigma0 + 0.001, t) - ...
               blackscholes_call(s, x, r, sigma0 - 0.001, t)) / 0.002;
        sigma1 = sigma0 + (price - blackscholes_call(s, x, r, sigma0, t)) ...
                / mylc;
        eps = (sigma1 - sigma0) ^ 2 / sigma0 ^ 2;
        sigma0 = sigma1;
    end
