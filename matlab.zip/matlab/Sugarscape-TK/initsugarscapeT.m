% InitsugarscapeT
% Initialize four-peak two-good sugarscape and display

function [s, ssugar, sspice] = initsugarscapeT(size, maxsugar, maxspice)

% Generate sugarscape of sugar with one south west peak
x = -ceil(0.75*size) : size-ceil(0.75*size)-1; 
y = -ceil(0.25*size) : size-ceil(0.25*size)-1;
maxresource = maxsugar;
stemp = initsugarscapeTb(size, maxresource, x, y);
s1 = stemp;

% Generate sugarscape of sugar with one north east peak
x = -ceil(0.25*size) : size-ceil(0.25*size)-1; 
y = -ceil(0.75*size) : size-ceil(0.75*size)-1;
maxresource = maxsugar;
stemp = initsugarscapeTb(size, maxresource, x, y);
s2 = stemp;

%Generate two-peak sugar sugarscape
ssugar = s1 + s2;

% Generate sugarscape of sugar with one south east peak
x = -ceil(0.75*size) : size-ceil(0.75*size)-1; 
y = -ceil(0.75*size) : size-ceil(0.75*size)-1;
maxresource = maxspice;
stemp = initsugarscapeTb(size, maxresource, x, y);
s3 = stemp;

% Generate sugarscape of sugar with one north west peak
x = -ceil(0.25*size) : size-ceil(0.25*size)-1; 
y = -ceil(0.25*size) : size-ceil(0.25*size)-1;
maxresource = maxspice;
s4 = initsugarscapeTb(size, maxresource, x, y);

% Generate two-peak sugar sugarscape
sspice = s3 + s4;

% Generate four-peak sugar and spice sugarscape
s = ssugar - sspice;

% Display four-peak sugar and spice sugarscape
figure(2);
colormap(parula);
imagesc(s);
axis square;
